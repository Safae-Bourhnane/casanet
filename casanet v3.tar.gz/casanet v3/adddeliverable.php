<?php
	include("connect.php");
		if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	if(isset($_POST['submit']) && $_FILES['file']['size'] > 0)
	{
		try{
	        $author = $_POST['author'];
			$title = $_POST['title'];
			$type = $_POST['type'];
			$conf = $_POST['conf'];	
			$fileName = $_FILES['file']['name'];
			$tmpName  = $_FILES['file']['tmp_name'];
			$fileSize = $_FILES['file']['size'];
			$fileType = $_FILES['file']['type'];

			$fp      = fopen($tmpName, 'r');
			$content = fread($fp, filesize($tmpName));
			fclose($fp);

			if(!get_magic_quotes_gpc())
			{
			    $fileName = addslashes($fileName);
			}

			$statement = $dbh->prepare("INSERT INTO deliverable(ID_project, author, title, type, confidentiality, file, upload_date, 
				file_name, file_size, file_type, status)
			    VALUES(:id, :author, :title, :type, :confidentiality, :file, CURDATE(), :file_name, :file_size, :file_type, :status)");
			$statement->execute(array(
				"id" => 1,
			    "author" => $author, 
			    "title" => $title, 
			    "type" => $type, 
			    "confidentiality" => $conf,
			    "file" => $content,
			    "file_name" => $fileName,
			    "file_size" => $fileSize,
			    "file_type" => $fileType,
			    "status" => "Approved"
			));
			header("Location: manage-deliverables.php");
		}
		catch(PDOException $e) {
		    print "Error!: " . $e->getMessage() . "<br/>";
		    die();
		}
	} 
	else{
		header('location: index.php');
	}
?>