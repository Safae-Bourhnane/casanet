<!DOCTYPE html>
<?php include("connect.php"); ?>

<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
    <meta charset="utf-8">
    <title>Discover - CASANET</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
  ================================================== -->
    <link rel="stylesheet" href="stylesheets/base.css">
    <link rel="stylesheet" href="stylesheets/skeleton.css">
    <link rel="stylesheet" href="stylesheets/layout.css">
    <link rel="stylesheet" href="stylesheets/flexslider.css">
    <link rel="stylesheet" href="stylesheets/prettyPhoto.css">
    <link rel="stylesheet" href="stylesheets/slider.css">
    
    <!-- CSS
  ================================================== -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/script.js"></script>

    <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

</head>
<body>
      <!-- Primary Page Layout
      ================================================== -->
      <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>

                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php" class="current">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION['login']) && $_SESSION['type'] == 'Member'){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
      </header>

      <div class="container">
        <article class="thirteen columns main-content">
            <h2 id="description"><a href='#'>CASANAET Description</a></h2>
            <p align="justify">
              <?php 
                  echo nl2br($_SESSION['description']);
              ?>
            </p>
            <hr>
            <h2 id="objectives"><a href='#'>CASANET Objectives</a></h2>
            <p align="justify">
              <?php 
                  echo nl2br($_SESSION['objectives']);
              ?>
            </p>
            <p align = "center"><img src="images/casanetobjectives.png" height="250" width="250"></p>
            <hr>
            <h2 id="outcomes"><a href='#'>CASANET Outcomes</a></h2>
            <p align="justify">
              <?php 
                  echo nl2br($_SESSION['outcomes']);
              ?>
            </p>
            <hr>
            <h2><a href='#'>Starting Date</a></h2> 01/01/2016 
            <hr>
            <h2><a href='#'>Ending Date</a></h2> 31/12/2018 
            <hr>
            <h2><a href='#'>Partners</a></h2> 
                <table border>
                 <tr>
                   <td><img src="images/partners/uir.jpe" height="42" width="42"></td>
                   <td style="text-align:center">UIR: Université Internationale de Rabat</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/AUI.png" height="42" width="42"></td>
                   <td style="text-align:center">AUI: Al Akhawayn University in Ifrane</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/logo_ensias.jpg" height="42" width="42"></td>
                   <td style="text-align:center">ENSIAS: Ecole Nationale Supérieure d'Informatique et Analyse des Systèmes</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/UAS.jpg" height="42" width="42"></td>
                   <td style="text-align:center">Université Abdelmalek Essaadi</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/mentis.jpe" height="42" width="42"></td>
                   <td style="text-align:center">Mentis</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/ibntofail.jpg" height="42" width="42"></td>
                   <td style="text-align:center">Université Ibntofail</td>
                 </tr>
                 <tr>
                   <td><img src="images/partners/algees.png" height="42" width="42"></td>
                   <td style="text-align:center">ALGEES</td>
                 </tr>
              </table>
              <br>
              <hr>
              <h2><a href='#'>Funding Agencies</a></h2>
             <table border>
               <tr>
                 <td><img src="images/mes.png" height="42" width="42"></td>
                 <td style="text-align:center">MESRSFC: Ministère de l’Enseignement Supérieur, de la Recherche Scientifique et de la Formation des Cadres.</td>
               </tr>
               <tr>
                 <td><img src="images/cnrst.png" height="42" width="42"></td>
                 <td style="text-align:center">CNRST: Centre National pour la Recherche Scientifique et Technique.</td>
               </tr>
             </table>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
        </article>
        


        <!-- End main Content -->
        <?php include("aside.php"); ?>


        <!-- End Right Sidebar -->
    
    </div>

    <footer>
      <div id="footer-base">
        <div class="container">
          <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
        </div>
      </div>
    </footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>


        
