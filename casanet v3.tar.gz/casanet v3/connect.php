<?php
	session_start();
	try{
		$dbh = new PDO('mysql:host=localhost;dbname=casanet', 'root', '');
       //$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       //$dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
       //$dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
	} catch (PDOException $e) {
	    print "Error!: " . $e->getMessage() . "<br/>";
	    die();
	}
?>