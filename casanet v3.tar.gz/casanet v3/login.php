<?php
	include('connect.php');
    if(isset($_POST['login'])){
        try{
            $password = hash( 'sha512', $_POST['password'] );
            $SQL = 'SELECT * from user where login = :login and password = :password';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':login', $_POST["login"]);
            $STH->bindParam(':password', $password);
            $STH->execute();
            $STH->setFetchMode(PDO::FETCH_ASSOC);

            if ($STH->rowCount() > 0) {
    	        while($row = $STH->fetch()) {
    	            $_SESSION['login'] = $row['login'];
    	            $_SESSION['first_name'] = $row['first_name'];
    	            $_SESSION['last_name'] = $row['last_name'];
    	            $_SESSION['type'] = $row['type'];
    	            $_SESSION['wrong'] = null;
    	            header('Location: index.php');
    	        }
            } else {
                $_SESSION['wrong'] = 'true';
    			header('Location: index.php');
            }
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
    }
    else{
        header('Location: index.php');
    }
?>