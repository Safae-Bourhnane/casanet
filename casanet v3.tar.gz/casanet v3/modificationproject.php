<?php
include("connect.php");
    if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
        header("location: index.php");
    }
	if(isset($_POST['mod']))
	{
        $id = $_POST['id'];
        $idp = 1;
        try{
            $SQL = 'UPDATE conference SET title=?, description=?, website=? WHERE ID=?';
            $STH = $dbh->prepare($SQL);
            $STH->execute(array($_POST["title"], $_POST["desc"], $_POST["website"], $_POST['id']));
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
	if(isset($_POST['del']))
	{
		try{
            $SQL = 'DELETE FROM conference WHERE ID=:id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $_POST["id"], PDO::PARAM_INT);
            $STH->execute();
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
	header('Location:administration.php'); 
?>