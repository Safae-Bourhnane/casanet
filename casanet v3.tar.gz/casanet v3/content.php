<?php include("connect.php"); 
    if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
        header("location: index.php");
    }
    ?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Manage Content - Casanet</title>
    <?php include("head.php"); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>

            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php"  class="current">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
    <article class="thirteen columns main-content">
        <h2>Modify Content</h2>
        
    <?php
        if(!isset($_SESSION['type']) || ($_SESSION['type'] != "Administrator" &&  $_SESSION['type'] != "Administrator")){
            header("Location: index.php");
        }
        try{
            $SQL = 'SELECT *  FROM content';
            $STH = $dbh->prepare($SQL);
            $STH->execute();
            $STH->setFetchMode(PDO::FETCH_ASSOC);

            if ($STH->rowCount() > 0) {
                echo '<div class = "eight columns">';
                echo '<form method="post" action="content.php">';
                while($row = $STH->fetch()) {
                    ?>
                    <h3 style="margin-left:30px">Introduction</h3>
                    <textarea name = "intro" cols="300" rows = "10" required><?php echo $row['introduction'] ; ?></textarea>
                    <br><hr><h3 style="margin-left:30px">Starting Date</h3>
                    <input type = "date" name = "startdate" required>
                    <br><hr><h3 style="margin-left:30px">Ending Date</h3>
                    <input type="date" name="enddate"required>
                    <br><hr><h3 style="margin-left:30px">Project Description</h3>
                    <textarea name = "desc" cols="300" rows = "10" required> <?php echo $row['description'] ; ?></textarea>
                    <br><hr><h3 style="margin-left:30px">Project Objectives</h3>
                    <textarea name = "obj" cols="300" rows = "10" required><?php echo $row['objectives'] ; ?></textarea>
                    <br><hr><h3 style="margin-left:30px">Project Outcomes</h3>
                    <textarea name = "out" cols="300" rows = "10" required><?php echo $row['outcomes'] ; ?></textarea>
                    <?php
                }
                echo '<input type = "submit" name = "modify" value="Modify" style="margin-left:30px">';
                echo '</form>';
                echo '</div>';
            } 
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }

        if(isset($_POST['modify']))
        {
            try{
                $SQL = 'UPDATE content SET description =:description, objectives = :objectives, 
                outcomes = :outcomes, introduction = :introduction, duration = :duration  WHERE ID=0';
                $STH = $dbh->prepare($SQL);
                $STH->bindParam(':description', $_POST['desc']);
                $STH->bindParam(':objectives', $_POST['obj']);
                $STH->bindParam(':outcomes', $_POST['out']);
                $STH->bindParam(':introduction', $_POST['intro']);
                $STH->bindParam(':duration', $_POST['duration']);

                $STH->execute();
                
            }
            catch(PDOException $e) {
                print "Error!: " . $e->getMessage() . "<br/>";
                die();
            }
        }

        ?>
        </article>
<?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    
    </div>
     <footer>
        <div id="footer-base">
            <div class="container">
                <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
            </div>
        </div>
    </footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

   