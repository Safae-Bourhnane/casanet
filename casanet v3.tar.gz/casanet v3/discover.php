<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>News</title>
    <?php include('head.php'); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="discover.php" class="current">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">        
        <article class="thirteen columns main-content">
            <br class="clear">
            
                <div class="littlemenu">  
                    <hr>
                    <a href = "project_description.php" class = "icon-folder-open"> Project Description >></a>
                    <a href = "partners.php" class = "icon-folder-open"> Partners >></a>
                </div>
            <hr>
        </article>
    <!-- End main Content -->
        

    <?php include("aside.php"); ?>
    <!-- End Right Sidebar -->
    
    </div>

<footer>
    <div id="footer-base">
        <div class="container">
            <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
        </div>
    </div>
</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

