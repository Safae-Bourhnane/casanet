<?php include("connect.php"); 
  if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
    header("location: index.php");
  }
?>
<!DOCTYPE html>

<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
  <title>Modify User - CASANET</title>
  <?php include("head.php"); ?>
</head>

<body>
 <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php"  class="current">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

<?php
    if(isset($_GET['iduser'])){
        try{
            $id  = $_GET['iduser'] ;
            $SQL = 'SELECT * FROM user WHERE login=:id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $id);
            $STH->execute();
            $STH->setFetchMode(PDO::FETCH_ASSOC);

            if ($STH->rowCount() > 0) {
                if($row["type"] == "Member"){
                  $select_member = "selected";
                  $select_administrator = "";
                }
                else{
                  $select_administrator = "";
                  $select_member = "selected";
                }
              while($row = $STH->fetch()) {
                  echo '<div class="container">
                    <article class="thirteen columns main-content">
                      <h2>Manage Users</h2>
                      <form name="insertion" action="modificationuser.php" method="POST">
                        <table border="0" align="center" cellspacing="2" cellpadding="2">
                          <tr align="center">
                            <td>First Name</td>
                            <td><input type="text" name="fn" value="'.$row['first_name'].'" required></td>
                          </tr>
                          <tr align="center">
                            <td>Last Name</td>
                            <td><input type="text" name="ln" value="'.$row['last_name'].'" required></td>
                          </tr>
                          <tr align="center">
                            <td>Email</td>
                            <td><input type="text" name="email" value="'.$row['email'].'" required></td>
                          </tr>
                          <tr align="center">
                            <td>Tel</td>
                            <td><input type="text" name="tel" value="'.$row['tel'].'" required></td>
                          </tr>
                          <tr align="center">
                            <td>Login</td>
                            <td><input type="text" name="login" value="'.$row['login'].'" required></td>
                          </tr>
                           <tr align="center">
                            <td>Password</td>
                            <td><input type="text" name="pass" id="pass" value="'.$row['password'].'" required></td>
                          </tr>
                           <tr align="center">
                            <td>Type</td>
                        <td><select name="conf">
                          <option value="Administrator" '. $select_administrator.'>Administrator</option>
                          <option value="Member" '. $select_member.'>Member</option>
                        </select></td>
                          </tr>
                          <tr align="center">
                            <td></td>
                            <td>
                              <input type="submit" name="mod" value="Modify">
                              <input type="submit" name="del" value="Delete" onclick="return confirm(\'Delete user?\');">
                            </td>
                          </tr>
                        </table>
                      </form>';
              }
            } else { 
              header('Location: manage-users.php');
            }
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
    }
    else{
       header('Location: manage-users.php');
    }
?>

      <br>
      <br>
      <br>
      <br><br>
 </article>
<?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    </div>
    <footer>
        <div id="footer-base">
            <div class="container">
                <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
            </div>
        </div>
    </footer>
<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

   
