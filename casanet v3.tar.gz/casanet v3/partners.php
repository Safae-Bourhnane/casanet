<!DOCTYPE html>
<?php include("connect.php"); ?>

<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <!-- Basic Page Needs
  ================================================== -->
    <title>Casanet Partners</title>
    <?php include("head.php"); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="discover.php" class="current">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">
      <article class="thirteen columns main-content">
        <h2>Partners</h2>

          <section id="slideshow">
              
            <div class="container1">
              <div class="c_slider"></div>
              <div class="slider">
                <figure>
                  <img src="images/partners/AUI.png" alt="" width="640" height="310" />
                  <figcaption>Al Akhawayn University in Ifrane</figcaption>

                </figure><!--
                --><figure>
                  <img src="images/partners/uir.jpe" alt="" width="640" height="310" />
                  <figcaption>Université Internationale de Rabat</figcaption>
                </figure><!--
                --><figure>
                  <img src="images/partners/UAS.jpg" alt="" width="640" height="310" />
                  <figcaption>Université Abdelmalek Essaadi</figcaption>

                </figure><!--
                --><figure>
                  <img src="images/partners/mentis.jpe" alt="" width="640" height="310" />
                  <figcaption>Mentis</figcaption>
                </figure>
                <figure>
                  <img src="images/partners/ibntofail.jpg" alt="" width="640" height="310" />
                  <figcaption>Université Ibntofail</figcaption>
                </figure>
                <figure>
                  <img src="images/partners/logo_ensias.jpg" alt="" width="640" height="310" />
                  <figcaption>Ecole Nationale Supérieure d'Informatique et Analyse des Systèmes</figcaption>
                </figure>
                 <figure>
             
              </div>
            </div>
            <br>
              
            <span id="timeline"></span>
          </section>


          <br><h3>International University of Rabat</h3>
          <p align="justify">The International University of Rabat or IUR is a private university founded in 2010 in Morocco. It delivers double-degrees, in collaboration with foreign universities, in law, engineering, aeronautics, energy engineering, architecture, business management and political sciences.<br>
          </p><br><br><hr>
          <h3>Al Akhawayn University in Ifrane</h3>
          <p align="justify">Al Akhawayn University (Arabic: جامعة الأخوين‎‎, meaning The Two Brothers' University referring to the King Fahd of Saudi Arabia, and King Hassan II of Morocco; French: Université Al Akhawayn) is an independent, public, not-for-profit, coeducational university located in Ifrane, Morocco, 70 km (43 mi) from the imperial city of Fez, in the midst of the Middle Atlas Mountains. It is independent, public, not-for-profit, and coeducational. The medium of instruction is the English -language.

          The creation of Al Akhawayn University was largely funded by the King of Saudi Arabia from an endowment intended for the cleanup of an oil spill off the coast of Morocco. The cleanup was never realized as the wind blew the oil spill away and the endowment was used to create the university. Al Akhawayn University was founded by Royal Decree (Dahir) in 1993 and officially inaugurated by the former King Hassan II of Morocco, on January 16, 1995.
          </p><br><hr>
          <h3>Abdelmalek Essaâdi University</h3>
          Abdelmalek Essaâdi University is a public university in Tetuan, Morocco, with a branch in Tangier. The university includes the following faculties and schools.
          <br><br>
          In Tetuan:
          <br>
          <ul style="list-style-type:disc; margin-left:50px;">
          <li>Faculty of Sciences</li>
          <li>National School of Applied Sciences, Tetuan Campus</li>
          <li>Polydisciplinary Faculty</li>
          <li>Higher Normal School , Ecole Normale Supérieure (ENS)</li>
          </ul>
          In Tangier:
          <br>

          <ul style="list-style-type:disc; margin-left:50px;">
            <li>National School of Applied Sciences, Tangier Campus</li>
            <li>National School of business and management, Ecole Nationale de Commerce et de Gestion (ENCG)</li>
            <li>Faculty of Sciences and Technology</li>
          </ul>
          The National Schools and the faculty of science and technology deliver a state engineering degree (Diplôme d’Ingénieur d’État). The other faculties deliver either a bachelor's (licence) or a master's degree.
          <br><br><hr>
          <h3>Mentis</h3>

          <p align="justify">
          Crée en 2011 autour d’une idée et d’un projet, par un groupe d’ingénieurs, avec le souci d’être un acteur national, à valeur ajoutée dans le domaine des technologies et systèmes d’information; Mentis n’a cessé de développer son métier :  Recherche et Développement autour des Nouvelles Technologies de l’Information et de Communication, Développement et réalisation produits et solutions à forte valeur ajoutée, L’ingénierie, systèmes, réseaux & télécommunications et veille technologique.


          </p><br><hr>

          <h3>The Higher School of Computer Science and System Analysis</h3>
          <p align="justify">L’École nationale supérieure d’informatique et d’analyse des systèmes (ENSIAS) est l'une des grandes écoles d'ingénieurs marocaines rattachée à l'université Mohammed V - Souissi de Rabat. Les étudiants et diplômés sont appelés les Ensiastes.
          </p><br><hr>
          <h3>Ibntofail University</h3>
          <p align="justify">The university Ibn Tufail (or ITU) is a Moroccan public university located in Kenitra.


          The university has attached several sectors and institutions, some of which were existing before its creation and who were attached later:
          <br>
          <ul style="list-style-type:disc; margin-left:50px;">
          <li>Faculty of Science (or FSK); opened in 1985</li>
          <li>Faculty of Arts and Humanities (or FLSHK); opened in 1985</li>
          <li>Faculty of Economic Sciences, Legal and Social (or FSEJSK); opened in 2004</li>
          <li>National School of Business and Management (or ENCGK); opened in 2005</li>
          <li>National School of Applied Sciences (or ENSAK); opened in 2008</li>
          </ul></p>
    </article>
<?php include("aside.php"); ?>

        <!-- End Right Sidebar -->
    
    </div>
<footer>
    <div id="footer-base">
        <div class="container">
            <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
        </div>
    </div>
</footer>


<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

   