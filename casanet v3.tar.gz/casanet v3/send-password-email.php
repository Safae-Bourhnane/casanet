<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Forgot Password</title>
    <?php include('head.php'); ?>

</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
        <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li>
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                                echo '<a href="deliverables-member.php">Deliverables</a>';
                            }
                            else{
                                echo '<a href="deliverables.php">Deliverables</a>';
                            }
                            ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>


    <div class="container">        
        <article class="thirteen columns main-content">

            <?php
                if(isset($_POST['submit'])){
                    try{
                        $SQL = 'SELECT * from user where email=:email';
                        $STH = $dbh->prepare($SQL);
                        $STH->bindParam(':email', $_POST["email"]);
                        $STH->execute();
                        $STH->setFetchMode(PDO::FETCH_ASSOC);

                        if ($STH->rowCount() > 0) {
                            while($row = $STH->fetch()) {
                                require 'PHPMailer/PHPMailerAutoload.php';

                                $mail = new PHPMailer;

                                $mail->isSMTP();                                   // Set mailer to use SMTP
                                $mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
                                $mail->SMTPAuth = true;                            // Enable SMTP authentication
                                $mail->Username = 'casanetmaroc@gmail.com';          // SMTP username
                                $mail->Password = 'casanetuir'; // SMTP password
                                $mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
                                $mail->Port = 587;                                 // TCP port to connect to

                                $mail->setFrom('casanetmaroc@gmail.com', 'Casanet Maroc');
                               // $mail->addReplyTo($_POST['email'], $_POST['name']);
                                $mail->addAddress($_POST['email']);   // Add a recipient
                                //$mail->addCC('cc@example.com');
                                //$mail->addBCC('bcc@example.com');

                                $mail->isHTML(true);  // Set email format to HTML

                                $bodyContent = '<h3>This email is sent to you upon your request on <a href="http://wwww.casanet.com">wwww.casanet.com</a></h3>
                                <h4>Please click on the link below to reset your password</h4>
                                <a href="http://www.casanet.com/reset-password.php?id='.$row['login'].'">www.casanet.com/reset-password?id='.$row['login'].'</a>';
                                $mail->Subject = 'Password reset instructions - Casanet Website';
                                $mail->Body    = $bodyContent;

                                if($mail->send()) {
                                    echo '<h2><a>Reset Your Password</a></h2><h3>The instructions to reset your password have been emailed to you. Please check your email.<h3>';
                                } else {
                                    echo '<h3>Couldn\'t send you an email. Please try again later. If the problem persists, please contact the website administrators.<h3>';
                                }
                            }
                        } else {
                            echo 'The email your have entered is not a valid one. 
                            Please make sure you have entered a valid email or contact the administartors to create a new account.';
                        }
                    }
                    catch(PDOException $e) {
                        print "Error!: " . $e->getMessage() . "<br/>";
                        die();
                    }
                }
                else{
                    header('Location: forgot-password.php');
                }

            ?>

        </article>
        <!-- End main Content -->
        
        <?php include('aside.php'); ?>
        <!-- End Right Sidebar -->
    
    </div>

<footer>



<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

