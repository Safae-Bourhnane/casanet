<?php
	include("connect.php");
    if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
        header("location: index.php");
    }
	if(isset($_POST['mod']))
	{
		try{
            $SQL = 'UPDATE user SET first_name = ?, last_name = ?, email= ?,
	     		tel = ?, password = ?, login = ?, type = ? WHERE login = ?';
            $STH = $dbh->prepare($SQL);
            $STH->execute(array($_POST["fn"], $_POST["ln"], $_POST["email"], $_POST["tel"], $_POST["pass"], 
                $_POST["login"], $_POST["type"],  $_POST["login"]));
            print_r($STH->errorInfo());
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
	if(isset($_POST['del']))
	{
		try{
            $SQL = 'DELETE FROM user WHERE login=:id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $_POST["login"]);
            $STH->execute();
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
    if(isset($_SESSION['type']) && $_SESSION['type'] == "Administrator"){
        header('Location:manage-users.php'); 
    }
    else{
        header("Location: index.php");
    }
?>