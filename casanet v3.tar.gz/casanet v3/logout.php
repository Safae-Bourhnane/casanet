<?php
	session_start();
	$_SESSION['login'] = null;
    $_SESSION['first_name'] = null;
    $_SESSION['last_name'] = null;
    $_SESSION['type'] = null;
    header('Location: index.php');
?>