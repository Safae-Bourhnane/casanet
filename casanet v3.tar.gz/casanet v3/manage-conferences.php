<!DOCTYPE html>
<?php include("connect.php"); 
    if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
        header("location: index.php");
    }
?>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Manage Conferences - Casanet</title>
    <?php include("head.php"); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                         <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php"  class="current">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <article class="thirteen columns main-content">
            <h2>Manage Conferences</h2>
            <h3 style="margin-left:30px">Add Conference</h3>
            <form method="POST" action="manage-conferences.php">
                <p style="margin-left:35px"> 
                Title  <input type = "text" name="title" required>
                Description  <textarea name = "desc" required></textarea>
                Website  <textarea name = "website" required></textarea>
                Date<br> <input type = "date" name="conference_date" required><br><br>
                Location <input type = "text" name="location" required>
                <br>
                <input type="submit" name = "submit" value="Add Conference">
            </form>
            <h3 style="margin-left:30px">Modify/Delete Conference</h3>
            <table border style = "width:1000px">
                <?php
                if(isset($_SESSION['type']) && $_SESSION['type'] == "Administrator"){
                    try{
                        $SQL = 'SELECT * from conference where type = "Conference"';
                        $STH = $dbh->prepare($SQL);
                        $STH->execute();
                        $STH->setFetchMode(PDO::FETCH_ASSOC);

                        if ($STH->rowCount() > 0) {
                            echo '<tr>';
                            echo '<th><h5>Title</th>';
                            echo '<th><h5>Description</th>';
                            echo '<th><h5>Website</th>';
                            echo '<th><h5>Date</th>';
                            echo '<th><h5>Location</th>';
                            echo '</tr>';
                            while($row = $STH->fetch()) {
                                echo '<tr>';
                                echo '<td>'.$row['title'].'</td>';
                                echo '<td>'.$row['description'].'</td>';
                                echo '<td>'.$row['website'].'</td>';
                                echo '<td>'.$row['conference_date'].'</td>';
                                echo '<td>'.$row['location'].'</td>';                                
                                echo '<td><a href = "modifyconference.php?idevent='.$row['ID'].'">Modify</a></td>';
                                echo '</tr>';
                            }
                        } else {
                           echo 'There are no conferences to show.';
                        }
                    }
                    catch(PDOException $e) {
                        print "Error!: " . $e->getMessage() . "<br/>";
                        die();
                    }
                }
                else{
                    header('Location: index.php');
                }

                if(isset($_POST['submit']))
                {
                    try{
                        $SQL = "INSERT into conference (ID_project, title, description, 
                        website, conference_date, location, type)
                        VALUES (:ID_project, :title, :description, :website, :conference_date, :location, :type)";
                        $STH = $dbh->prepare($SQL);
                        $id = 1;
                        $type = "Conference";
                        $STH->bindParam(':ID_project', $id);
                        $STH->bindParam(':title', $_POST['title']);
                        $STH->bindParam(':description', $_POST['desc']);
                        $STH->bindParam(':website', $_POST['website']);
                        $STH->bindParam(':conference_date', $_POST['conference_date']);
                        $STH->bindParam(':location', $_POST['location']);
                        $STH->bindParam(':type', $type);
                        $STH->execute();
                        
                    }
                    catch(PDOException $e) {
                        print "Error!: " . $e->getMessage() . "<br/>";
                        die();
                    }
                    header('Location: administration.php');
                }
                ?>
            </table>
        </article>

        <?php include("aside.php"); ?>

        <!-- End Right Sidebar -->
    
    </div>
<br><br><br>
    <footer>
        <div id="footer-base">
            <div class="container">
                <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
            </div>
        </div>
    </footer>
<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

   