<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Contact Us</title>
    <?php include("head.php"); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->

        <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php" class="current">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">        
        <article class="thirteen columns main-content">
            <br class="clear">
            <h1>People Involved</h1>
            <table>
                <tr>
                <th><h3>Institution</h3></th>
                <th><h3>Full Name</h3></th>
                <th><h3>Contact Info</h3></th>
                </tr>
                <tr>
                <td align = "center">Université Internationale de Rabat</td>
                <td>Mohamed Bakhouya</td>
                <td><a href="mailto:mohamed.bakhouya@uir.ac.ma">mohamed.bakhouya@uir.ac.ma</a></td>
                </tr>
                <tr>
                <td align = "center">Université Internationale de Rabat</td>
                <td>Fadwa Lachhab</td>
                <td><a href="mailto:fadwa.lachhab@uir.ac.ma">fadwa.lachhab@uir.ac.ma</a></td>
                </tr>
                <tr>
                <td align = "center">Ecole Nationale Supérieure d'Informatique et Analyse des Système</td>
                <td>Mohammed Essaaidi</td>
                <td><a href="mailto:essaaidi@ieee.org">essaaidi@ieee.org</a></td>
                </tr>
                <tr>
                <td align = "center">Al Akhawayn University in Ifrane</td>
                <td>Mohamed Riduan ABID</td>
                <td><a href="mailto:r.abid@aui.ma">r.abid@aui.ma</a></td>
                </tr>
                <tr>
                <td align = "center">Al Akhawayn University in Ifrane</td>
                <td>Hassane Darhmaoui</td>
                <td><a href="mailto:h.darhmaoui@aui.ma">h.darhmaoui@aui.ma</a></td>
                </tr>
                <tr>
                <td align = "center">Al Akhawayn University in Ifrane</td>
                <td>Najem Naji</td>
                <td><a href="mailto:n.naji@aui.ma">n.naji@aui.ma</a></td>
                </tr>
                <tr>
                <td align = "center">ENSA-Kénitra - Université Ibn Tofaïl</td>
                <td>Nissrine Krami</td>
                <td><a href="mailto:nissrinekrami@yahoo.com">nissrinekrami@yahoo.com</a></td>
                </tr>
                <tr>
                <td align = "center">Uiversité Abdelmalek Essaadi- Faculté des Sciences Tanger</td>
                <td>Mohamed Elbrak</td>
                <td><a href="mailto:elbrak.m@gmail.com">elbrak.m@gmail.com</a></td>
                </tr>
                <tr>
                <td align = "center">Mentis</td>
                <td>Mohamed Bnehadou</td>
                <td><a href="mailto:mbenhaddou@mentis-consulting.be">mbenhaddou@mentis-consulting.be</a></td>
                </tr>
                <tr>
                <td align = "center">ALGEES</td>
                <td>Mohamed Berdai</td>
                <td><a href="mailto:mo.berdai.ct@gmail.com">mo.berdai.ct@gmail.com</a></td>
                </tr>
            </table>
            <br>
            <hr>
            <br>
            <h1>Contact Us</h1>
            <form action="send-email.php" method="post">
                <input type="text" name="name" placeholder="Enter your name" required> 
                <input type="text" name="email" placeholder="Enter your email" required> 
                <input type = "text" name="subject" placeholder="Subject..." required>
                <textarea name="message" rows="5" cols="40" placeholder="Enter your message" required></textarea><br>
                <input name="submit" type="submit" onclick="return confirm('Send the email?')" value="Send email">
            </form>
        </article>
        <!-- End main Content -->
        
        
        <?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    
    </div>
    <br><br>

<footer>



<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

