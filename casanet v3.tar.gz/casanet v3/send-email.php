<?php
	require 'PHPMailer/PHPMailerAutoload.php';

	$mail = new PHPMailer;

	$mail->isSMTP();                                   // Set mailer to use SMTP
	$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
	$mail->SMTPAuth = true;                            // Enable SMTP authentication
	$mail->Username = 'casanetmaroc@gmail.com';          // SMTP username
	$mail->Password = 'casanetuir'; // SMTP password
	$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
	$mail->Port = 587;                                 // TCP port to connect to

	$mail->setFrom($_POST['email'], $_POST['name']);
	$mail->addReplyTo($_POST['email'], $_POST['name']);
	$mail->addAddress('casanetmaroc@gmail.com');   // Add a recipient
	//$mail->addCC('cc@example.com');
	//$mail->addBCC('bcc@example.com');

	$mail->isHTML(true);  // Set email format to HTML

	$bodyContent = $_POST['message'];
	$mail->Subject = $_POST['subject'];
	$mail->Body    = $bodyContent;

	if(!$mail->send()) {
	    header('location: send-email-failed.php');
	} else {
	    header('location: contact-us-thank-you.php');
	}
?>