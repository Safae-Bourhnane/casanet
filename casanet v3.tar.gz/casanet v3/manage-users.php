<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Manage Users</title>
    <?php include('head.php'); ?>
</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php" class="current">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">        
        <article class="thirteen columns main-content">
        <br class="clear">
        <h2>Manage Users</h2>
        <h3 style="margin-left:30px">Add User</h3>
            <form method="POST" action="adduser.php">
                <p style="margin-left:35px"> 
                First Name  <input type = "text" name="fn" required>
                Last Name  <input type = "text" name="ln" required>
                Email  <input type = "text" name="email" required>
                Tel <input type = "text" name="tel" required>
                Login <input type = "text" name="login" id="login" required>
                Password <input type = "text" name="password" required>
                Type <select name = "type" required>
                    <option value="Administrator">Administrator</option>
                    <option value="Member">Member</option>
                </select>
                <br>
                <input type="submit" name = "submit" value="Add User">
            </form>
        <br>
        <h3 style="margin-left:30px">Modify/Delete User</h3>
            <?php
                try{
                    if(isset($_SESSION['type']) && $_SESSION['type'] == "Administrator"){
                        $SQL = 'SELECT * from user';
                    }
                    else{
                        header("location: index.php");
                    }
                    $STH = $dbh->prepare($SQL);
                    $STH->execute();
                    $STH->setFetchMode(PDO::FETCH_ASSOC);

                    if ($STH->rowCount() > 0) {
                        echo '<table border>';
                        echo '<tr>';
                        echo '<th>Name</th>';
                        echo '<th>Type</th>';
                        echo '<th>Email</th>';
                        echo '<th>Tel</th>';
                        echo '<th>Login</th>';
                        echo '<th>Password</th>';
                        echo '</tr>';
                        while($row = $STH->fetch()) {
                            echo '<tr>';
                                echo '<td align="center">'.$row["first_name"].' '.$row["last_name"].'</td>';
                                echo '<td align="center">'.$row['type'].'</td>';
                                echo '<td align="center">'.$row['email'].'</td>';
                                echo '<td align="center">'.$row['tel'].'</td>';  
                                echo '<td align="center">'.$row['login'].'</td>';       
                                echo '<td align="center" style="width:500px; overflow: hidden; display: inline-block; white-space: nowrap;">'.$row['password'].'</td>';     
                                echo '<td align="center"><a href = "modifyuser.php?iduser='.$row['login'].'">Modify</a></td>';           
                                echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo 'There are no deliverables to show.';
                    }
                }
                catch(PDOException $e) {
                    print "Error!: " . $e->getMessage() . "<br/>";
                    die();
                }
            ?>
        </article>
        
        <!-- End main Content -->
        <?php include('aside.php'); ?>

        <!-- End Right Sidebar -->
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>
    <div id="footer-base">
        <div class="container">
            <center><img src ="images/1.jpg" width = "50" height = "50"></center>    
        </div>
    </div>
</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

