<aside class="three columns right-sidebar">
    <div class = "leftbar">
        <h2>Search</h2>
        <form action="search.php" method="post">
            <input name="keywords" type="text" placeholder="Search..." required>
        </form>

        <?php
            if(!isset($_SESSION['login'])){
            ?>
                <h2>Login</h2>
                <form action="login.php" method="post">
                    <input name="login" type="text" placeholder="Username" required>
                    <input name="password" type="password" placeholder="Password" required>
                    <?php
                        if (isset($_SESSION['wrong'])) {
                    ?>
                    <p id="Invalid" style="padding-top:.75em; color:#FF0000;">Invalid Login Or Password</p>
                    <?php
                        $_SESSION['wrong'] = null;
                        }
                    ?>
                    <input name="submit" type="submit" value="Sign in">
                </form>  
                <a href = "forgot-username.php" class = "icon-question-sign"> Forgot your username?</a><br>
                <a href = "forgot-password.php" class = "icon-question-sign"> Forgot your password?</a>
            <?php
            }
            else{
                echo '<strong>'.$_SESSION['type'].'</strong>: '.$_SESSION['first_name'].' '.$_SESSION['last_name'].'<br><strong>Status</strong>: <font color="green">Connected</font><br>';
                ?><a href="logout.php" onclick="return confirm('Confirm Log Out?')">Log out</a>
        <?php
            }
        ?>
    </div>
</aside>