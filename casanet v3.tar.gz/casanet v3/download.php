<?php
    include("connect.php");
        if(isset($_GET['id'])){
            try{
                // Our tokens match, proceed with the view

                $stmt = $dbh->prepare("SELECT file, file_name, file_size, file_type FROM deliverable where id =".$_GET['id']);
                $stmt->execute();

                $row = $stmt->fetch();
                header("Content-Type: $row[3]");
                header("Content-Length: $row[2]");
                header("Content-disposition: attachment; filename=$row[1]");
                //echo $fRes[0][file]; 
                print $row[0];
                exit;
            }
            catch(PDOException $e) {
                print "Error!: " . $e->getMessage() . "<br/>";
                die();
            }
        }
        else{
            header('location: index.php');
        }
?>