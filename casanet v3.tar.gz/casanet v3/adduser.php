<?php
	include("connect.php");
		if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	error_reporting(0);
	try{
		$First_name = $_POST['fn'];
		$Last_name = $_POST['ln'];
		$Email = $_POST['email'];
		$Tel = $_POST['tel'];
		$login = $_POST['login'];
		$password = hash( 'sha512', $_POST['password'] );
		$type = $_POST['type'];

            $SQL = 'SELECT * from user where login = :login';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':login', $_POST["login"]);
            $STH->execute();
            $STH->setFetchMode(PDO::FETCH_ASSOC);

            if ($STH->rowCount() > 0) {
    	        echo '<script> alert("The login you entered already exists! Please try another one."); 
    	        	window.location = "manage-users.php";
    	        </script>';
			}

			$SQL = 'SELECT * from user where email = :email';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':email', $_POST["email"]);
            $STH->execute();
            $STH->setFetchMode(PDO::FETCH_ASSOC);

            if ($STH->rowCount() > 0) {
    	        echo '<script> alert("The email you have entered already exists. Please try another one."); 
    	        	window.location = "manage-users.php";
    	        </script>';
			}
		
			include("verify.php");

			$valid = (verifyEmail($_POST['email'], 'bourhnane.safae@gmail.com'));

		/*	if($valid == "invalid"){
			 	echo '<script> alert("Please enter a valid email");
			 		window.location = "manage-users.php";
			 	</script>';
			}*/
			
			//else{
				$stmt = $dbh->prepare('INSERT INTO user (first_name, last_name, email, tel, password, login, type)
				VALUES (:fn, :ln, :email, :tel, :password, :login, :type)');
				$stmt->bindParam(':fn', $_POST["fn"]);
				$stmt->bindParam(':ln', $_POST["ln"]);
				$stmt->bindParam(':email', $_POST["email"]);
				$stmt->bindParam(':tel', $_POST["tel"]);
				$stmt->bindParam(':password', $password);
				$stmt->bindParam(':login', $_POST["login"]);
				$stmt->bindParam(':type', $_POST["type"]);

				$stmt->execute();

				header('Location: manage-users.php');
			//}
	}
	catch (PDOException $e) {
		print "Error!: " . $e->getMessage() . "<br/>";
		die();
	}

?>