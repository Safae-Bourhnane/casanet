<?php
    try{
        foreach($dbh->query('SELECT * from content ORDER BY ID_project DESC LIMIT 1') as $row) {
            $_SESSION['logo'] = $row["logo"];
            $_SESSION['img'] = $row['img'];
            $_SESSION['title'] = $row["title"];
            $_SESSION['introduction'] = $row['introduction'];
            $_SESSION['description'] = $row["description"];
            $_SESSION['objectives'] = $row['objectives'];
            $_SESSION['outcomes'] = $row['outcomes'];
        }
    }
    catch(PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
?>