<?php
	include("connect.php");
		if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	try{
		$First_name = $_POST['fn'];
		$Last_name = $_POST['ln'];
		$Email = $_POST['email'];
		$Tel = $_POST['tel'];
		$login = $_POST['login'];
		$password = $_POST['password'];
		$type = $_POST['type'];

		$stmt = $dbh->prepare('INSERT INTO events (ID_project, title, description, start_date, end_date, location, full_presentation)
		VALUES (:id, :title, :description, :start_date, :end_date, :location, :full_presentation)');
		$stmt->bindParam(':id', $_POST["id"]);
		$stmt->bindParam(':title', $_POST["title"]);
		$stmt->bindParam(':description', $_POST["description"]);
		$stmt->bindParam(':start_date', $_POST["start_date"]);
		$stmt->bindParam(':end_date', $_POST["end_date"]);
		$stmt->bindParam(':location', $_POST["location"]);
		$stmt->bindParam(':full_presentation', $_POST["full_presentation"]);

		$stmt->execute();

		header('Location: manage-events.php');
	} 
	catch (PDOException $e) {
		print "Error!: " . $e->getMessage() . "<br/>";
		die();
	}

?>