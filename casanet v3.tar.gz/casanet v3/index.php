<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Welcome - Home</title>
    <?php include('head.php'); ?>

</head>
<body>
    <?php include("initialize.php"); ?>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php" class="current">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">        
        <article class="thirteen columns main-content">
        <center><h1>
            <?php 
                echo nl2br($_SESSION['title']);
            ?>
        </h1></center>
        <br>
        <hr>
        <div class = "seven columns">
            <center><h2>Introduction</h2></center>
            <p class = "intro">
                <?php 
                    echo nl2br($_SESSION['introduction']);
                ?>
            </p>
        </div>
        <div class = "three columns">
            <center><h2>&nbsp;</h2></center>
            <img class = "intropic" src= <?php echo $_SESSION["img"]; ?> width="90%" height="90%">
        </div> 
        <br class="clear">
        <hr>
        <div class="littlemenu">  
        <a href = "project_description.php#description" class = "icon-folder-open"> Project Description</a>
        <a href = "project_description.php#objectives" class = "icon-folder-open"> Objectives</a>
        <a href = "project_description.php#outcomes" class = "icon-folder-open"> Project Outcomes</a>
        </div>
        <br>
        <hr>

                                <section id="slideshow">
                  <div class="container1">
                    <div class="c_slider"></div>
                    <div class="slider">
                     <figure>
                        <img src="images/partners/uir.jpe" alt="" width="250" height="125" />
                      </figure>
                      <figure>
                        <img src="images/partners/AUI.png" alt="" width="250" height="125" />
                      </figure>
                     <figure>
                        <img src="images/partners/logo_ensias.jpg" alt="" width="250" height="125" />
                      </figure>
                      <figure>
                        <img src="images/partners/UAS.jpg" alt="" width="250" height="125" />
                      </figure><!--
                      --><figure>
                        <img src="images/partners/mentis.jpe" alt="" width="250" height="125" />
                      </figure>
                      <figure>
                        <img src="images/partners/ibntofail.jpg" alt="" width="250" height="125" />
                      </figure>
                       <figure>
                    </div>
                  </div>
                  <br>
                    
                  <span id="timeline"></span>
                </section>
        <h2><a href = "#" class = "icon-calendar"> Upcoming Events</a></h2>
        
            <?php 
                try{
                    $SQL = "SELECT * from events where start_date >= CURDATE()";
                    $STH = $dbh->prepare($SQL);
                   // $STH->bindParam(':member_id', $member_id);
                    $STH->execute();
                    $STH->setFetchMode(PDO::FETCH_ASSOC);

                    if ($STH->rowCount() > 0) {
                        echo '<div id = "scrollbox">';
                        while($row = $STH->fetch()) {
                            echo '<strong>'.print_r($row['title'], true).'</strong>: '.print_r($row['location'], true);
                            echo '<p>'.print_r($row['start_date'], true).' - '.print_r($row['end_date'], true).'</p>';
                            echo '<hr>';
                        }
                        echo '</div>';
                    } else {
                       echo 'There are no upcoming events.';
                    }
                }
                catch(PDOException $e) {
                    print "Error!: " . $e->getMessage() . "<br/>";
                    die();
                }
            ?>       
            <br>  
            <br>  
        

        </article>
        <!-- End main Content -->
        
        <?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    
    </div>
<footer>

<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

