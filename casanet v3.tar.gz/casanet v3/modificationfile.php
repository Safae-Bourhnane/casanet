<?php
	include("connect.php");
	if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	if(isset($_POST['mod']))
	{
		try{
			$id = $_POST['id'];
	        $author = $_POST['author'];
			$title = $_POST['title'];
			$type = $_POST['type'];
			$conf = $_POST['conf'];	
			if($_FILES['file']['size'] > 0){
				$fileName = $_FILES['file']['name'];
				$tmpName  = $_FILES['file']['tmp_name'];
				$fileSize = $_FILES['file']['size'];
				$fileType = $_FILES['file']['type'];
				$fp      = fopen($tmpName, 'r');
				$content = fread($fp, filesize($tmpName));
				fclose($fp);

				if(!get_magic_quotes_gpc())
				{
				    $fileName = addslashes($fileName);
				}
				$statement = $dbh->prepare("UPDATE deliverable SET author = ?, title = ?, type = ?,
	     		confidentiality = ?, file = ?, file_name = ?, 
	     		file_size = ?, file_type = ? WHERE ID = ?");
				$statement->execute(array($author, $title, $type, $conf, $content, $fileName, $fileSize, $fileType, $id));
			}
			else{
				$statement = $dbh->prepare("UPDATE deliverable SET author = ?, title = ?, type= ?,
	     		confidentiality = ? WHERE ID = ?");
				$statement->execute(array($author, $title, $type, $conf, $id));
			}
		}
		catch(PDOException $e) {
		    #print "Error!: " . $e->getMessage() . "<br/>";
		    die();
		}
	} 
	if(isset($_POST['del']))
	{
		try{
            $SQL = 'DELETE FROM deliverable WHERE ID=:id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $_POST["id"], PDO::PARAM_INT);
            $STH->execute();
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
	if(isset($_SESSION['type']) && $_SESSION['type'] == "Administrator"){
        header('Location:manage-deliverables.php'); 
    }
	else{
		header('location: index.php');
	}
?>