<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>News - Events</title>
    <?php include('head.php'); ?>

</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
        <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php" class="current">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">        
        <article class="thirteen columns main-content">
        <br class="clear">
        <h2><a href = "#" class = "icon-calendar"> Events</a></h2>
            <h3>Events From</h3>
	        <form action="news-events.php" method="post">
	        	<input style="float:left;height:24.5px;" type="date" name='from_date' size='9' value=""> 
	            <input style="float:left; margin-left:10px;" name="event_keyword" type="text" placeholder="Search...">
	            <input style="float:left; margin-left:10px;" type="submit" value="Search">
	        </form>
        <hr>
        <?php
        	if( (isset( $_POST['from_date']) && trim( $_POST['from_date'] ) != "" && trim( $_POST['from_date'] ) != "1970-01-01")
        		|| (isset($_POST['event_keyword']) && $_POST['event_keyword'] != "") ) {
        ?>

        <h2><a href = "#" class = "icon-calendar"> Search Results</a></h2>
            <?php 
                try{
                	if($_POST['event_keyword'] != ""){
                        $var1 = $_POST['event_keyword'];
                        if(isset($_POST['from_date'])){
                            $from = date("Y-m-d", strtotime($_POST['from_date']));
                            $SQL = 'SELECT * from events where title LIKE ? AND start_date >= ?';
                            $params = array("%$var1%", "$from");
                            $STH = $dbh->prepare($SQL);
                        }
                        else{
                            $SQL = 'SELECT * from events where title LIKE ? OR description LIKE ? OR full_presentation LIKE ?';
                            $STH = $dbh->prepare($SQL);
                            $params = array("%$var1%", "%$var1%", "%$var1%");
                            $STH = $dbh->prepare($SQL);
                        }
                        $STH->execute($params);
                	}
                	else{
                        $my_date = date("Y-m-d", strtotime($_POST['from_date']));
                		$SQL = 'SELECT * from events where start_date >= :my_date';
                        $STH = $dbh->prepare($SQL);
			        	$STH->bindParam(':my_date', $my_date, PDO::PARAM_STR);
                        $STH->execute();
                	}			        
			        $STH->setFetchMode(PDO::FETCH_ASSOC);

			        if ($STH->rowCount() > 0) {
			        	echo '<div id = "scrollbox">';
				        while($row = $STH->fetch()) {
				            echo '<strong>'.print_r($row['title'], true).'</strong>: '.print_r($row['location'], true);
	                        echo '<br>'.print_r($row['start_date'], true).' - '.print_r($row['end_date'], true);
	                        echo '<br><strong>Description</strong>: '.print_r($row['description'], true);
                    	    echo'     
                                <br>               
                                <a href="#openModal">Find Out More >></a>

                                <div id="openModal" class="modalDialog">
                                    <div>
                                        <a href="#close" title="Close" class="close">X</a>
                                        <h2>'.$row["title"].'</h2>
                                        <p><h3>Date </h3>'.$row["start_date"].' - '.$row["end_date"].'</p>
                                        <p><h3>Location </h3>'.$row["location"].'</p>
                                        <p><h3>Description</h3> '.$row["description"].'</p>
                                        <p><h3>Full Description</h3>'.$row["full_presentation"].'</p>
                                    </div>
                                </div>
                            ';


	                        echo '<hr>';
				        }
				        echo '</div>';
			        } else {
			            echo 'There are no events with the criteria you are looking for.';
			        }
			    }
			    catch(PDOException $e) {
			        print "Error!: " . $e->getMessage() . "<br/>";
			        die();
			    }
            ?>       
            <br>  
            <br>  
        <hr>
        <?php
        		$_POST['from_date'] = null;
        		$_POST['event_keyword'] = null;
    		}	
        ?>
        
        <h2><a href = "#" class = "icon-calendar"> Upcoming Meetings</a></h2>
            <?php 
                try{
			        $SQL = 'SELECT * from meeting where start_date >= CURDATE()';
			        $STH = $dbh->prepare($SQL);
			        $STH->execute();
			        $STH->setFetchMode(PDO::FETCH_ASSOC);

			        if ($STH->rowCount() > 0) {
			        	echo '<div id = "scrollbox">';
				        while($row = $STH->fetch()) {
				            echo '<strong>'.print_r($row['title'], true).'</strong>: '.print_r($row['location'], true);
	                        echo '<br>'.print_r($row['start_date'], true).' - '.print_r($row['end_date'], true);
	                        echo '<br><strong>Description</strong>: '.print_r($row['description'], true);
	                        echo'     
                                <br>               
                                    <a href="#openModal">Find Out More >></a>

                                    <div id="openModal" class="modalDialog">
                                        <div>
                                            <a href="#close" title="Close" class="close">X</a>
                                            <h2>'.$row["title"].'</h2>
                                            <p><h3>Date </h3>'.$row["start_date"].' - '.$row["end_date"].'</p>
                                            <p><h3>Location </h3>'.$row["location"].'</p>
                                            <p><h3>Description</h3> '.$row["description"].'</p>
                                            <p><h3>Full Description</h3>'.$row["full_description"].'</p>
                                        </div>
                                    </div>
                            ';
	                        echo '<hr>';
				        }
				        echo '</div>';
			        } else {
			            echo 'There are no upcoming meetings.';
			        }
			    }
			    catch(PDOException $e) {
			        print "Error!: " . $e->getMessage() . "<br/>";
			        die();
			    }
            ?>       
            <br>  
            <br>  
        <hr>
        <h2><a href = "#" class = "icon-calendar"> Past Meetings</a></h2>
            <?php 
                try{
			        $SQL = 'SELECT * from meeting where start_date < CURDATE()';
			        $STH = $dbh->prepare($SQL);
			        $STH->execute();
			        $STH->setFetchMode(PDO::FETCH_ASSOC);

			        if ($STH->rowCount() > 0) {
			        	echo '<div id = "scrollbox">';
				        while($row = $STH->fetch()) {
				            echo '<strong>'.print_r($row['title'], true).'</strong>: '.print_r($row['location'], true);
	                        echo '<br>'.print_r($row['start_date'], true).' - '.print_r($row['end_date'], true);
	                        echo '<br><strong>Description</strong>: '.print_r($row['description'], true);
	                        echo'     
                                <br>               
                                <a href="#openModal">Find Out More >></a>

                                <div id="openModal" class="modalDialog">
                                    <div>
                                        <a href="#close" title="Close" class="close">X</a>
                                        <h2>'.$row["title"].'</h2>
                                        <p>'.$row["start_date"].' to '.$row["end_date"].'</p>
                                        <p>Location: '.$row["location"].'</p>
                                        <p><h3>Description: </h3> '.$row["description"].'</p>
                                        <p><h3>Full Description</h3>'.$row["full_description"].'
                                    </div>
                                </div>
                            ';
	                        echo '<hr>';
				        }
				        echo '</div>';
			        } else {
			            echo 'There are no past meetings.';
			        }
			    }
			    catch(PDOException $e) {
			        print "Error!: " . $e->getMessage() . "<br/>";
			        die();
			    }
            ?>       
            <br>  
            <br>  

        </article>
        <!-- End main Content -->
        
        <?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    </div>
<footer>

<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

