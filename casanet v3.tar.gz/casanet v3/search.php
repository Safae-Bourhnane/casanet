<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Search Results</title>
    <?php include('head.php'); ?>

</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'admin'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">        
        <article class="thirteen columns main-content">
        	<?php
	            if(isset($_POST['keywords'])){
			        try{
			        	echo '<h2><a>Search Results for: </a>'.$_POST["keywords"].'</h2>';
			        	$found = false;
			        	$parts = preg_split('/\s+/', $_POST['keywords']);
			        	for($i = 0; $i < count($parts); $i++) {
			        		$var1 = $parts[$i];

			        		$SQL = 'SELECT DISTINCT * from deliverable where confidentiality="Public" and status="Approved" and title LIKE ?';
	                        $params = array("%$var1%");
	                        $STH = $dbh->prepare($SQL);
	                        $STH->execute($params);
	                        $STH->setFetchMode(PDO::FETCH_ASSOC);

				            if ($STH->rowCount() > 0) {
				    	        $found = true;
				    	        echo '<h3>Deliverables</h3>';
				    	        while($row = $STH->fetch()) {
				    	        	echo '<a href = "deliverables.php">'.$row['title'].'</a> by: '.$row['author'].'<br>';
				    	        }
				    	        echo '<hr>';
				    	        $i = count($parts);
				            }


					        $SQL = 'SELECT DISTINCT * from events where title LIKE ? OR description LIKE ? OR full_presentation LIKE ?';
	                        $params = array("%$var1%", "%$var1%", "%$var1%");
	                        $STH = $dbh->prepare($SQL);
	                        $STH->execute($params);
	                        $STH->setFetchMode(PDO::FETCH_ASSOC);

				            if ($STH->rowCount() > 0) {
				    	        $found = true;
				    	        echo '<h3>Events</h3>';
				    	        while($row = $STH->fetch()) {
				    	        	echo '<a href = "news-events.php">'.$row['title'].'</a>: '.$row['description'];
				    	        	echo '<br>Start date: '.$row['start_date'].'<br>';
				    	        }
				    	        $i = count($parts);
				    	        echo '<hr>';
				            }

					        $SQL = 'SELECT DISTINCT * from conference where title LIKE ? OR description LIKE ?';
	                        $params = array("%$var1%", "%$var1%");
	                        $STH = $dbh->prepare($SQL);
	                        $STH->execute($params);
	                        $STH->setFetchMode(PDO::FETCH_ASSOC);

				            if ($STH->rowCount() > 0) {
				    	        $found = true;
				    	        echo '<h3>Projetcs And Conferences</h3>';
				    	        while($row = $STH->fetch()) {
				    	        	echo '<a href = "news-conferences.php">'.$row['title'].'</a>: '.$row['description'];
				    	        	echo '<br>Start date: <a href = "'.$row['website'].'">'.$row['website'].'<br>';
				    	        }
				    	        $i = count($parts);
				    	        echo '<hr>';
				            }

				            $SQL = 'SELECT DISTINCT * from meeting where title LIKE ? OR description LIKE ? OR full_description LIKE ?';
	                        $params = array("%$var1%", "%$var1%", "%$var1%");
	                        $STH = $dbh->prepare($SQL);
	                        $STH->execute($params);
	                        $STH->setFetchMode(PDO::FETCH_ASSOC);

				            if ($STH->rowCount() > 0) {
				    	        $found = true;
				    	        echo '<h3>Meetings</h3>';
				    	        while($row = $STH->fetch()) {
				    	        	echo '<a href = "news-events.php">'.$row['title'].'</a>: '.$row['description'];
				    	        	echo '<br>Start date: '.$row['start_date'].'<br>';
				    	        }
				    	        $i = count($parts);
				    	        echo '<hr>';
				            }
					    }
					    if($found == false){
					    	echo 'No results were found for the keywords you have typed.';
					    }
				    }
				    catch(PDOException $e) {
				        print "Error!: " . $e->getMessage() . "<br/>";
				        die();
				    }
			    }
			    else{
			        header('Location: index.php');
			    }
			?>

        </article>
        <!-- End main Content -->
        

        <?php include("aside.php"); ?>
        <!-- End Right Sidebar -->
    
    </div>
<footer>



<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>

