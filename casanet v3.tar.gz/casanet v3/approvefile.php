<?php
	include('connect.php');
    if(isset($_SESSION['login']) && $_SESSION['type'] == "Administrator"){
        try{
            $SQL = 'UPDATE deliverable SET status = "Approved" WHERE ID = :id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $_GET["id"]);
            $STH->execute();
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
         header('Location: manage-deliverables.php');
    }

    else{
        header('Location: index.php');
    }
?>