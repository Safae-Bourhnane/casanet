<?php
	include("connect.php");
		if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
		header("location: index.php");
	}
	try{
		$First_name = $_POST['fn'];
		$Last_name = $_POST['ln'];
		$Email = $_POST['email'];
		$Tel = $_POST['tel'];
		$login = $_POST['login'];
		$password = $_POST['password'];
		$type = $_POST['type'];

		$stmt = $dbh->prepare('INSERT INTO conference (ID_project, title, description, website, conference_date, location, type)
		VALUES (:id, :title, :description, :website, :conference_date, :location, :type)');
		$stmt->bindParam(':id', 1);
		$stmt->bindParam(':title', $_POST["title"]);
		$stmt->bindParam(':description', $_POST["desc"]);
		$stmt->bindParam(':start_date', $_POST["website"]);
		$stmt->bindParam(':conference_date', $_POST["conference_date"]);
		$stmt->bindParam(':location', $_POST["location"]);
		$stmt->bindParam(':type', $_POST["type"]);

		$stmt->execute();

		header('Location: manage-conferences.php');
	} 
	catch (PDOException $e) {
		print "Error!: " . $e->getMessage() . "<br/>";
		die();
	}

?>