<?php
include("connect.php");
    if(!isset($_SESSION['type']) || $_SESSION['type'] != "Administrator"){
        header("location: index.php");
    }
	if(isset($_POST['mod']))
	{
        $id = $_POST['id'];
        try{
            $SQL = 'UPDATE conference SET ID_project = ?, title = ?, description = ?, conference_date = ?, type = ?,
            website = ?, location = ? WHERE ID = ?';
            $STH = $dbh->prepare($SQL);
            $id_proj = 1;
            $type = "conference";
            $STH->execute(array($id_proj, $_POST["title"], $_POST["desc"], $_POST["dateconf"], $type, $_POST["website"], $_POST["location"], $id));
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
	if(isset($_POST['del']))
	{
		try{
            $SQL = 'DELETE FROM conference WHERE ID=:id';
            $STH = $dbh->prepare($SQL);
            $STH->bindParam(':id', $_POST["id"], PDO::PARAM_INT);
            $STH->execute();
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
	}
    if(isset($_SESSION['type']) && $_SESSION['type'] == "Administrator"){
        header('Location:administration.php'); 
    }
    else{
        header("Location: index.php");
    }
?>