<?php 
    include('connect.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
    <title>Reset Password</title>
    <?php include('head.php'); ?>
    <script>
        function submit()
        {
            var x=document.getElementById("new-password");
            var y=document.getElementById("new-password-confirmation");
            if (x.value == y.value) {
                return true;
            }
            else{
                window.alert=("The passwords you have entered are not identical!");
                return false;
            }
        }
    </script>

</head>
<body>
    <!-- Primary Page Layout
    ================================================== -->
    <header id="header" class="site-header" role="banner">
        <div id="header-inner" class="container sixteen columns over">
            <hgroup class="one-third column alpha">
                <h1 id="site-title" class="site-title">
                <a href="index.php" id="logo"><img src=<?php echo $_SESSION["logo"]; ?> alt="Icebrrrg logo" height="30%" width="30%" /></a>
                </h1>
            </hgroup>
            <nav id="main-nav" class="two thirds column omega">
                <ul id="main-nav-menu" class="nav-menu">
                    <li id="menu-item-1">
                        <a href="index.php">Home</a>
                    </li>
                    <li id="menu-item-2">
                        <a href="news.php">News</a>
                    </li>
                    <li id="menu-item-3">
                        <a href="project_description.php">Discover</a>
                    </li>
                    <li id="menu-item-4">
                        <?php if(isset($_SESSION["type"]) && $_SESSION["type"] == "Member"){
                            echo '<a href="deliverables-member.php">Deliverables</a>';
                        }
                        else{
                            echo '<a href="deliverables.php">Deliverables</a>';
                        }
                        ?>
                    </li>
                    <li id="menu-item-5">
                        <a href="contact.php">Contact</a>
                    </li>
                    <?php
                        if(isset($_SESSION['login']) && $_SESSION['type'] == 'Administrator'){
                            echo '
                                <li id="menu-item-6">
                                    <a href="administration.php">Administration</a>
                                </li>
                            ';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">        
        <article class="thirteen columns main-content">

<?php 
    if(isset($_POST['submit'])){
        try{
            $password = hash( 'sha512', $_POST['new-password'] );

            $query = $dbh->prepare("UPDATE user SET password = ? WHERE login = ? ");

            $query->execute(array($password, $_POST['id']));

            if($query->rowCount()==1){   
                echo '<h2><a>Password Reset</a></h2>';
                echo '<h3>Your password has been updated. You can now log in using your new password.</h3>';
            } else {
    			header('Location: reset-password.php');
            }
        }
        catch(PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
    }
    else{
        header('Location: reset-password.php');
    }
?>



        </article>
        <!-- End main Content -->
        
        
        <?php include('aside.php'); ?>
        <!-- End Right Sidebar -->
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br>

<footer>



<div id="footer-base">
<div class="container">
<center><img src ="images/1.jpg" width = "50" height = "50"></center>    
</div>
</div>

</footer>

<!-- End Document
================================================== -->

<script src="js/jquery.prettyPhoto.js"></script>
</body>
</html>